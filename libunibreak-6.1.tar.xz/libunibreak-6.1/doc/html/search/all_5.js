var searchData=
[
  ['flb21ahebrew_0',['fLb21aHebrew',['../structLineBreakContext.html#aae9c8c4e457a7c31683779d095532251',1,'LineBreakContext']]],
  ['flb8azwj_1',['fLb8aZwj',['../structLineBreakContext.html#a54024680e48e955ed6635f51a18b4366',1,'LineBreakContext']]]
];
