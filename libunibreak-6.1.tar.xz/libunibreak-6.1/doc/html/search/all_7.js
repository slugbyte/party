var searchData=
[
  ['incb_5fconsonant_0',['InCB_Consonant',['../indicconjunctbreakdef_8h.html#a1746745c40254a121061d3e231e127a8a67423c2575e0337e0d91372cabfc4ab8',1,'indicconjunctbreakdef.h']]],
  ['incb_5fextend_1',['InCB_Extend',['../indicconjunctbreakdef_8h.html#a1746745c40254a121061d3e231e127a8aa61470287556251409157c34f2a682dc',1,'indicconjunctbreakdef.h']]],
  ['incb_5flinker_2',['InCB_Linker',['../indicconjunctbreakdef_8h.html#a1746745c40254a121061d3e231e127a8af120f5181abe31d600e6d3c837a0b075',1,'indicconjunctbreakdef.h']]],
  ['incb_5fnone_3',['InCB_None',['../indicconjunctbreakdef_8h.html#a1746745c40254a121061d3e231e127a8a92b1f029e6af9ac0cef1e94202684a83',1,'indicconjunctbreakdef.h']]],
  ['ind_5fbrk_4',['IND_BRK',['../linebreak_8c.html#a440c1a7abb9df5e3fc1d27b9a39e3a8da1f049bd3227f78701750a314bb65b6cc',1,'linebreak.c']]],
  ['indicconjunctbreakclass_5',['IndicConjunctBreakClass',['../indicconjunctbreakdef_8h.html#a1746745c40254a121061d3e231e127a8',1,'indicconjunctbreakdef.h']]],
  ['indicconjunctbreakdata_2ec_6',['indicconjunctbreakdata.c',['../indicconjunctbreakdata_8c.html',1,'']]],
  ['indicconjunctbreakdef_2eh_7',['indicconjunctbreakdef.h',['../indicconjunctbreakdef_8h.html',1,'']]],
  ['indicconjunctbreakproperties_8',['IndicConjunctBreakProperties',['../structIndicConjunctBreakProperties.html',1,'']]],
  ['init_5fgraphemebreak_9',['init_graphemebreak',['../graphemebreak_8c.html#aaad521cb6d3ab7e6d312ddbff4da869d',1,'init_graphemebreak(void):&#160;graphemebreak.c'],['../graphemebreak_8h.html#aaad521cb6d3ab7e6d312ddbff4da869d',1,'init_graphemebreak(void):&#160;graphemebreak.c']]],
  ['init_5flinebreak_10',['init_linebreak',['../linebreak_8c.html#a57c2b88b7e1277cbba23cfffbc782c4f',1,'init_linebreak(void):&#160;linebreak.c'],['../linebreak_8h.html#a57c2b88b7e1277cbba23cfffbc782c4f',1,'init_linebreak(void):&#160;linebreak.c']]],
  ['init_5fwordbreak_11',['init_wordbreak',['../wordbreak_8c.html#a9be1d054399581a38051e450e8a60482',1,'init_wordbreak(void):&#160;wordbreak.c'],['../wordbreak_8h.html#a9be1d054399581a38051e450e8a60482',1,'init_wordbreak(void):&#160;wordbreak.c']]],
  ['is_5fline_5fbreakable_12',['is_line_breakable',['../linebreak_8c.html#a5761f60559b5ddb61bb095f00c7deb5c',1,'is_line_breakable(utf32_t char1, utf32_t char2, const char *lang):&#160;linebreak.c'],['../linebreak_8h.html#a5761f60559b5ddb61bb095f00c7deb5c',1,'is_line_breakable(utf32_t char1, utf32_t char2, const char *lang):&#160;linebreak.c']]],
  ['is_5fwb3ab_13',['IS_WB3ab',['../wordbreak_8c.html#a092ff924382ce3ce5fabe99255346dda',1,'wordbreak.c']]]
];
