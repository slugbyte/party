var searchData=
[
  ['ub_5fbsearch_0',['ub_bsearch',['../unibreakdef_8c.html#a076deefabad0418dd2b2691c9c256185',1,'ub_bsearch(utf32_t ch, const void *ptr, size_t count, size_t size):&#160;unibreakdef.h'],['../unibreakdef_8h.html#a076deefabad0418dd2b2691c9c256185',1,'ub_bsearch(utf32_t ch, const void *ptr, size_t count, size_t size):&#160;unibreakdef.h']]],
  ['ub_5fget_5fchar_5feaw_5fclass_1',['ub_get_char_eaw_class',['../eastasianwidthdef_8c.html#a4f307815ca17457d30f2283ff2b4d6a8',1,'ub_get_char_eaw_class(utf32_t ch):&#160;eastasianwidthdef.c'],['../eastasianwidthdef_8h.html#a4f307815ca17457d30f2283ff2b4d6a8',1,'ub_get_char_eaw_class(utf32_t ch):&#160;eastasianwidthdef.c']]],
  ['ub_5fget_5fnext_5fchar_5futf16_2',['ub_get_next_char_utf16',['../unibreakdef_8c.html#adea8e968bcb1389bd071f1088631eac8',1,'ub_get_next_char_utf16(const utf16_t *s, size_t len, size_t *ip):&#160;unibreakdef.c'],['../unibreakdef_8h.html#adea8e968bcb1389bd071f1088631eac8',1,'ub_get_next_char_utf16(const utf16_t *s, size_t len, size_t *ip):&#160;unibreakdef.c']]],
  ['ub_5fget_5fnext_5fchar_5futf32_3',['ub_get_next_char_utf32',['../unibreakdef_8c.html#ad60acf884ef809aaa2b07a47584da27f',1,'ub_get_next_char_utf32(const utf32_t *s, size_t len, size_t *ip):&#160;unibreakdef.c'],['../unibreakdef_8h.html#ad60acf884ef809aaa2b07a47584da27f',1,'ub_get_next_char_utf32(const utf32_t *s, size_t len, size_t *ip):&#160;unibreakdef.c']]],
  ['ub_5fget_5fnext_5fchar_5futf8_4',['ub_get_next_char_utf8',['../unibreakdef_8c.html#a4c74f21cb5f73cf9572f149d26558523',1,'ub_get_next_char_utf8(const utf8_t *s, size_t len, size_t *ip):&#160;unibreakdef.c'],['../unibreakdef_8h.html#a4c74f21cb5f73cf9572f149d26558523',1,'ub_get_next_char_utf8(const utf8_t *s, size_t len, size_t *ip):&#160;unibreakdef.c']]],
  ['ub_5fis_5fextended_5fpictographic_5',['ub_is_extended_pictographic',['../emojidef_8c.html#a538e0aae0f78469f3cd45c53d0a94857',1,'ub_is_extended_pictographic(utf32_t ch):&#160;emojidef.c'],['../emojidef_8h.html#a538e0aae0f78469f3cd45c53d0a94857',1,'ub_is_extended_pictographic(utf32_t ch):&#160;emojidef.c']]],
  ['unibreak_5futf_5ftypes_5fdefined_6',['UNIBREAK_UTF_TYPES_DEFINED',['../unibreakbase_8h.html#ac9149d5a4efc8690a97d07338fc9eb94',1,'unibreakbase.h']]],
  ['unibreak_5fversion_7',['UNIBREAK_VERSION',['../unibreakbase_8h.html#ae61a59be2ea65292900e5cd8699ed3b2',1,'unibreakbase.h']]],
  ['unibreak_5fversion_8',['unibreak_version',['../unibreakbase_8c.html#a00447944791d6ca9af108a6e14d85470',1,'unibreak_version:&#160;unibreakbase.c'],['../unibreakbase_8h.html#a00447944791d6ca9af108a6e14d85470',1,'unibreak_version:&#160;unibreakbase.c']]],
  ['unibreakbase_2ec_9',['unibreakbase.c',['../unibreakbase_8c.html',1,'']]],
  ['unibreakbase_2eh_10',['unibreakbase.h',['../unibreakbase_8h.html',1,'']]],
  ['unibreakdef_2ec_11',['unibreakdef.c',['../unibreakdef_8c.html',1,'']]],
  ['unibreakdef_2eh_12',['unibreakdef.h',['../unibreakdef_8h.html',1,'']]],
  ['utf16_5ft_13',['utf16_t',['../unibreakbase_8h.html#a4dce96cad338d9281612277b2d80950c',1,'unibreakbase.h']]],
  ['utf32_5ft_14',['utf32_t',['../unibreakbase_8h.html#a4f775bae0642c213be2c526018283c25',1,'unibreakbase.h']]],
  ['utf8_5ft_15',['utf8_t',['../unibreakbase_8h.html#a6103b2105588f239c593e779e605038a',1,'unibreakbase.h']]]
];
