var searchData=
[
  ['wordbreakproperties_0',['WordBreakProperties',['../structWordBreakProperties.html',1,'']]]
];
