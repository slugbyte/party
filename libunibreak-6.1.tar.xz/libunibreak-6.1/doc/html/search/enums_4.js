var searchData=
[
  ['linebreakclass_0',['LineBreakClass',['../linebreakdef_8h.html#a884b6565d87a81bbf549980bbdd04070',1,'linebreakdef.h']]]
];
