var searchData=
[
  ['r9c_5fend_0',['R9C_END',['../graphemebreak_8c.html#a854ff61d896f1f13ec04476b727400f8a581e3eb1755d2aa4ed854c4227dcfbac',1,'graphemebreak.c']]],
  ['r9c_5finactive_1',['R9C_INACTIVE',['../graphemebreak_8c.html#a854ff61d896f1f13ec04476b727400f8ad76cb610d69d2e3c9c103a760cd16aa7',1,'graphemebreak.c']]],
  ['r9c_5flinker_2',['R9C_LINKER',['../graphemebreak_8c.html#a854ff61d896f1f13ec04476b727400f8ac3f78ac1f554e2fd1ce008a1a3939d1b',1,'graphemebreak.c']]],
  ['r9c_5fstarted_3',['R9C_STARTED',['../graphemebreak_8c.html#a854ff61d896f1f13ec04476b727400f8a6d7d48e8a59d5347907dc5cc63af6d4e',1,'graphemebreak.c']]]
];
