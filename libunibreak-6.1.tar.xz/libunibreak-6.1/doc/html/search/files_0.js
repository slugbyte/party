var searchData=
[
  ['eastasianwidthdata_2ec_0',['eastasianwidthdata.c',['../eastasianwidthdata_8c.html',1,'']]],
  ['eastasianwidthdef_2ec_1',['eastasianwidthdef.c',['../eastasianwidthdef_8c.html',1,'']]],
  ['eastasianwidthdef_2eh_2',['eastasianwidthdef.h',['../eastasianwidthdef_8h.html',1,'']]],
  ['emojidata_2ec_3',['emojidata.c',['../emojidata_8c.html',1,'']]],
  ['emojidef_2ec_4',['emojidef.c',['../emojidef_8c.html',1,'']]],
  ['emojidef_2eh_5',['emojidef.h',['../emojidef_8h.html',1,'']]]
];
