var searchData=
[
  ['lb_5fget_5fchar_5fclass_0',['lb_get_char_class',['../linebreak_8c.html#a8573846e78e41155717b5a2d9288943b',1,'lb_get_char_class(const struct LineBreakContext *lbpCtx, utf32_t ch):&#160;linebreak.c'],['../linebreakdef_8h.html#a8573846e78e41155717b5a2d9288943b',1,'lb_get_char_class(const struct LineBreakContext *lbpCtx, utf32_t ch):&#160;linebreak.c']]],
  ['lb_5finit_5fbreak_5fcontext_1',['lb_init_break_context',['../linebreak_8c.html#a223651256f2b3a13d2cbf6401527008b',1,'lb_init_break_context(struct LineBreakContext *lbpCtx, utf32_t ch, const char *lang):&#160;linebreak.c'],['../linebreakdef_8h.html#a223651256f2b3a13d2cbf6401527008b',1,'lb_init_break_context(struct LineBreakContext *lbpCtx, utf32_t ch, const char *lang):&#160;linebreak.c']]],
  ['lb_5fprocess_5fnext_5fchar_2',['lb_process_next_char',['../linebreak_8c.html#aec336a0d889b2915c5e764179632ee39',1,'lb_process_next_char(struct LineBreakContext *lbpCtx, utf32_t ch):&#160;linebreak.c'],['../linebreakdef_8h.html#aec336a0d889b2915c5e764179632ee39',1,'lb_process_next_char(struct LineBreakContext *lbpCtx, utf32_t ch):&#160;linebreak.c']]]
];
